# Please install OpenAI SDK first: `pip3 install openai`
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv(".env")

def chat(prompt,temperature):
    client = OpenAI(
        api_key=os.environ.get('DEEPSEEK_API_KEY'),
        base_url="https://api.deepseek.com")

    response = client.chat.completions.create(
        model="deepseek-chat",
        messages=prompt,
        stream=True,
        temperature=temperature
    )

    full_response = ""
    for chunk in response:
        # 提取每一块内容（注意：不同 API 的提取路径可能略有不同）
        content = chunk.choices[0].delta.content
        if content:
            full_response += content
            yield full_response  # 👈 关键：逐字向外“吐”出目前积累的所有文本
    

