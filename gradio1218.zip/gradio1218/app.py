import gradio as gr
from llm.deepseek import chat
from memory.history import ChatInterface

chat_interface = ChatInterface()
def respond(message, history,temperature,SYSTEM_PROMPT):
    # ChatInterface默认参数表message和history
    print(temperature)
    print(SYSTEM_PROMPT)
    user_text = message["text"]
    uploaded_files = message["files"] # 这是一个包含文件路径的列表
    yield from chat_interface.send_message(user_text,uploaded_files,history,temperature,SYSTEM_PROMPT)

def export_history():
    # 我们打算把记录存成一个 Markdown 文件
    file_path = "chat_history.md"
    
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("# 📜 聊天记录导出\n\n")
        
        # 遍历后台的记忆
        for msg in chat_interface.history:
            # 判断是谁在说话
            role = "👤 **用户**" if msg["role"] == "user" else "🤖 **AI 助手**"
            
            # 因为之前加入了多模态，用户的 content 可能是个包含文字和图片的列表
            content = msg["content"]
            if isinstance(content, list):
                # 如果是多模态列表，我们只把里面的文字部分提取出来保存
                text_parts = [item["text"] for item in content if item["type"] == "text"]
                text = " ".join(text_parts)
            else:
                # 否则直接就是纯文本
                text = content
            
            # 写入文件，每句话后面加两个换行符保证排版美观
            f.write(f"{role}:\n> {text}\n\n")
            f.write("---\n") # 加一条分割线
            
    # 最后返回这个文件的路径，告诉 Gradio 文件准备好了
    return file_path

with gr.Blocks() as demo:
    # 顶部可以加个标题
    gr.Markdown("<center><h1>🤖 我的全能 AI 助手</h1></center>")

    chat_ui = gr.ChatInterface(
        fn=respond,
        multimodal=True,
        # 开启多模态后，message不再是字符串而是一个字典，长这样：
        # {"text": "图片里是什么？", "files": ["/路径/图片1.jpg", "/路径/图片2.png"]}
        additional_inputs=[
            
            gr.Slider(
                minimum=0.0, 
                maximum=2.0, 
                value=0.7, 
                step=0.1, 
                label="🌡️ Temperature (温度 - 创造力)",
                render=False,
                # 防止block提前渲染
            ),
            gr.Textbox(
                value="你是一个热于助人的AI助手",
                lines=3,
                label="🎭 System Prompt (系统提示词/人设)",
                placeholder="请输入AI的人设",
                render=False,
            ),
        
            
        ],)

    with gr.Row():
        export_btn = gr.Button("💾 导出聊天记录 (Markdown格式)", variant="primary")
        download_file = gr.File(label="📥 点击下载你的文件",height=30)
        
    # 3. 核心机制：绑定点击事件！
    # 当按钮(export_btn)被点击时，执行生成文件函数(export_history)，并将结果输出到文件框(download_file)
    export_btn.click(
        fn=export_history, 
        outputs=download_file
    )


demo.launch(share=False)