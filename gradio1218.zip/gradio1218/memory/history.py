from llm.deepseek import chat
# from prompt import SYSTEM_PROMPT
import base64

class ChatInterface:
    def __init__(self):
        self.history = []
    
    # 辅助函数：把本地图片转成 base64 编码
    def encode_image(self, image_path):
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    

    def send_message(self,user_text,uploaded_files,history,temperature,SYSTEM_PROMPT):
        if len(history) == 0:
            self.history = [] 
            print("🔄 监测到前端清空，后台记忆已重置！")

        content_list = []
        # 1. 放入文字
        if user_text:
            content_list.append({"type": "text", "text": user_text})
            
        # 2. 放入图片
        if uploaded_files:
            # 遍历上传的所有图片
            for file_path in uploaded_files:
                base64_image = self.encode_image(file_path)
                content_list.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
                    # data:

                    # 意思是：“注意啦，接下来的内容不是一个普通的网页链接（不是 http://...），而是直接的原始数据！”

                    # image/jpeg;

                    # 意思是：“这份数据的类型是一张图片，具体格式是 JPEG。”（虽然写着 jpeg，但大多数大模型 API 也很聪明，能自动兼容处理 png 等格式）。

                    # base64,

                    # 意思是：“这份图片数据是用 base64 这种编码方式翻译成文字的。逗号后面就是正文了！”

                    # {base64_image}

                    # 意思是：这里就是你刚才用 encode_image 函数翻译出来的那一大串英文字母和数字。这是 Python 的 f-string 语法，会自动把你变量里的内容填到这个大括号的位置。
                })

        self.history.append({"role": "user", "content": content_list})

        api_messages=[{"role": "user", "content": SYSTEM_PROMPT}]+self.history
        # 因为 chat 现在是一个生成器，我们需要遍历它
        full_reply = ""
        for current_text in chat(api_messages,temperature):
            full_reply = current_text # 记录最后完整的结果用于存入历史
            yield current_text        # 实时把文字传给前端
            
        # 当流式结束以后，再把完整的回复存入历史
        self.history.append({"role": "assistant", "content": full_reply})
        #因为使用的是yeild输出，所以返回完全部内容后会执行这句，把完整的回复存入历史

    